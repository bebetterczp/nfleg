package cn.nfleg.service;

import java.util.List;

import cn.nfleg.bean.Order_PostBean;
import cn.nfleg.dao.OrderDao;
import cn.nfleg.dao.OrderDaoImpl;

public class OrderServiceImpl implements OrderService{
	private static OrderDao orderdao = new OrderDaoImpl();
	@Override
	public boolean addOrder(int uid, short pid) {
		// TODO Auto-generated method stub
		return orderdao.addOrder(uid, pid);
	}
	@Override
	public List<Order_PostBean> getOrderByUid(int uid) {
		// TODO Auto-generated method stub
		return orderdao.getOrderByUid(uid);
	}
	@Override
	public boolean FinishOrderByOid(int oid, int id) {
		// TODO Auto-generated method stub
		return orderdao.FinishOrderByOid(oid, id);
	}
	@Override
	public boolean FinishOrderByPid(int pid, int id) {
		// TODO Auto-generated method stub
		return orderdao.FinishOrderByPid(pid, id);
	}

}
