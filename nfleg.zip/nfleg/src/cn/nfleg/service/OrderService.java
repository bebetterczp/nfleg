package cn.nfleg.service;

import java.util.List;

import cn.nfleg.bean.Order_PostBean;

public interface OrderService {
	public boolean addOrder(int uid,short pid);
	public List<Order_PostBean> getOrderByUid(int uid);
	public boolean FinishOrderByOid(int oid,int id);
	public boolean FinishOrderByPid(int pid,int id);
}
