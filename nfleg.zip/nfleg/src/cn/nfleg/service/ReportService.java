package cn.nfleg.service;

import java.util.List;

import cn.nfleg.bean.ReportBean;

public interface ReportService {
	public boolean AddReport(ReportBean reportbean);
	public List<ReportBean> queryAllReport();
}
