package cn.nfleg.service;

import java.util.List;

import cn.nfleg.bean.PostBean;

public interface PostService {
	public List<PostBean> getALLPost(); 
	public List<PostBean> getUserPost(int uid);
	PostBean getPostByID(Integer  postID);
	public boolean updatePostState(Integer valueOf);
	public boolean addPost(PostBean postbean);
	public boolean delPost(int uid, int postID);
	
}
