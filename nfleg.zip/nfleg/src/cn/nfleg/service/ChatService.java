package cn.nfleg.service;

import java.util.List;

import cn.nfleg.bean.ChatBean;
import cn.nfleg.bean.UserBean;

public interface ChatService {
	public boolean toUserExists(int uid);
	public List<ChatBean> chatList(int froUserID,int toUserID);
	public List<UserBean> chatUsers(int uid);
	public boolean AddChat(ChatBean chatbean);
}
