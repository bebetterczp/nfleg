package cn.nfleg.service;

import java.util.List;

import cn.nfleg.bean.ReportBean;
import cn.nfleg.dao.ReportDao;
import cn.nfleg.dao.ReportDaoImpl;

public class ReportServiceImpl implements ReportService{
	ReportDao reportdao = new ReportDaoImpl();

	@Override
	public boolean AddReport(ReportBean reportbean) {
		// TODO Auto-generated method stub
		return reportdao.AddReport(reportbean);
	}

	@Override
	public List<ReportBean> queryAllReport() {
		// TODO Auto-generated method stub
		return reportdao.queryAllReport();
	}

}
