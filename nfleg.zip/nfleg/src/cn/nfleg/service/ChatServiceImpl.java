package cn.nfleg.service;

import java.util.List;

import cn.nfleg.bean.ChatBean;
import cn.nfleg.bean.UserBean;
import cn.nfleg.dao.ChatDao;
import cn.nfleg.dao.ChatDaoImpl;

public class ChatServiceImpl implements ChatService{
	
	static ChatDao chatdao = new ChatDaoImpl();
	
	@Override
	public boolean toUserExists(int uid) {
		// TODO Auto-generated method stub
		return chatdao.toUserExists(uid);
	}

	@Override
	public List<ChatBean> chatList(int froUserID, int toUserID) {
		// TODO Auto-generated method stub
		return chatdao.chatList(froUserID, toUserID);
	}

	@Override
	public List<UserBean> chatUsers(int uid) {
		// TODO Auto-generated method stub
		return chatdao.chatUsers(uid);
	}

	@Override
	public boolean AddChat(ChatBean chatbean) {
		// TODO Auto-generated method stub
		return chatdao.AddChat(chatbean);
	}

}
