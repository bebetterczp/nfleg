package cn.nfleg.service;

public interface UserService {
	public boolean updateInfo(int uid ,String uname,String upwd);
	public boolean addMoney(int uid,double amount);
	public double showMoney(int uid);
	public int register(String uname,String upwd);
}
