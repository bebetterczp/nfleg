package cn.nfleg.service;

import cn.nfleg.dao.UserDao;
import cn.nfleg.dao.UserDaoImpl;

public class UserServiceImpl implements UserService{
	
	UserDao userdao = new UserDaoImpl();
	
	@Override
	public boolean updateInfo(int uid, String uname, String upwd) {
		// TODO Auto-generated method stub
		return userdao.updateInfo(uid, uname, upwd);
	}

	@Override
	public boolean addMoney(int uid, double amount) {
		// TODO Auto-generated method stub
		return userdao.addMoney(uid, amount);
	}

	@Override
	public double showMoney(int uid) {
		// TODO Auto-generated method stub
		return userdao.showMoney(uid);
	}

	@Override
	public int register(String uname, String upwd) {
		// TODO Auto-generated method stub
		return userdao.register(uname, upwd);
	}

}
