package cn.nfleg.service;

import cn.nfleg.bean.UserBean;

public interface LoginService {
	UserBean getUser(Integer uid,String pwd);
}
