package cn.nfleg.service;

import cn.nfleg.bean.UserBean;
import cn.nfleg.dao.LoginDao;
import cn.nfleg.dao.LoginDaoImpl;

public class LoginServiceImpl implements LoginService{

	static LoginDao logindao = new LoginDaoImpl();
	
	@Override
	public UserBean getUser(Integer uid,String pwd) {
		// TODO Auto-generated method stub
		return logindao.getUser(uid,pwd);
	}
	
}
