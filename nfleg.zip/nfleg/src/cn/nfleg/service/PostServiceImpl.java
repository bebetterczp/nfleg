package cn.nfleg.service;

import java.util.List;

import cn.nfleg.bean.PostBean;
import cn.nfleg.dao.PostDao;
import cn.nfleg.dao.PostDaoImpl;

public class PostServiceImpl implements PostService{
	
	private PostDao postdao = new PostDaoImpl(); 
	
	@Override
	public List<PostBean> getALLPost() {
		// TODO Auto-generated method stub
		return postdao.getALLPost();
	}

	@Override
	public List<PostBean> getUserPost(int uid) {
		// TODO Auto-generated method stub
		return postdao.getUserPost(uid);
	}

	@Override
	public PostBean getPostByID(Integer postID) {
		return postdao.getPostByID(postID);
	}

	@Override
	public boolean updatePostState(Integer postID) {
		return postdao.updatePostIntegerByID(postID);
	}

	@Override
	public boolean addPost(PostBean postbean) {
		// TODO Auto-generated method stub
		return postdao.addPost(postbean);
	}

	@Override
	public boolean delPost(int uid, int postID) {
		// TODO Auto-generated method stub
		return postdao.delPost(uid, postID);
	}

}
