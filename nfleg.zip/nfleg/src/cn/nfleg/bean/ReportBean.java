package cn.nfleg.bean;

public class ReportBean {
	private int id;
	private int fromUserID;
	private short reportType;
	private int toUserID;
	private short toPostID;
	private String reason;
	private String reportImgUrl;
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public int getFromUserID() {
		return fromUserID;
	}
	public void setFromUserID(int fromUserID) {
		this.fromUserID = fromUserID;
	}
	public short getReportType() {
		return reportType;
	}
	public void setReportType(short reportType) {
		this.reportType = reportType;
	}
	public int getToUserID() {
		return toUserID;
	}
	public void setToUserID(int toUserID) {
		this.toUserID = toUserID;
	}
	public short getToPostID() {
		return toPostID;
	}
	public void setToPostID(short toPostID) {
		this.toPostID = toPostID;
	}
	public String getReason() {
		return reason;
	}
	public void setReason(String reason) {
		this.reason = reason;
	}
	public String getReportImgUrl() {
		return reportImgUrl;
	}
	public void setReportImgUrl(String reportImgUrl) {
		this.reportImgUrl = reportImgUrl;
	}

	
	
	
	
	

}
