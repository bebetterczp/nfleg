package cn.nfleg.bean;

import java.io.Serializable;
import java.util.Date;

public class Order_PostBean implements Serializable{
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private int oid;
	private int fromUserID;
	private short pid;
	private short orderState1;
	private short orderState2;
	private short appraiseID;
	private int userID;
	private String userName;
	private String title;
	private String content;
	private String imgUrl;
	private Date time; //....
	private double amount;
	private String address;
	public int getOid() {
		return oid;
	}
	public void setOid(int oid) {
		this.oid = oid;
	}
	public int getFromUserID() {
		return fromUserID;
	}
	public void setFromUserID(int fromUserID) {
		this.fromUserID = fromUserID;
	}
	public short getPid() {
		return pid;
	}
	public void setPid(short pid) {
		this.pid = pid;
	}
	public short getOrderState1() {
		return orderState1;
	}
	public void setOrderState1(short orderState1) {
		this.orderState1 = orderState1;
	}
	public short getOrderState2() {
		return orderState2;
	}
	public void setOrderState2(short orderState2) {
		this.orderState2 = orderState2;
	}
	public short getAppraiseID() {
		return appraiseID;
	}
	public void setAppraiseID(short appraiseID) {
		this.appraiseID = appraiseID;
	}
	public int getUserID() {
		return userID;
	}
	public void setUserID(int userID) {
		this.userID = userID;
	}
	public String getUserName() {
		return userName;
	}
	public void setUserName(String userName) {
		this.userName = userName;
	}
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public String getContent() {
		return content;
	}
	public void setContent(String content) {
		this.content = content;
	}
	public String getImgUrl() {
		return imgUrl;
	}
	public void setImgUrl(String imgUrl) {
		this.imgUrl = imgUrl;
	}
	public Date getTime() {
		return time;
	}
	public void setTime(Date time) {
		this.time = time;
	}
	public double getAmount() {
		return amount;
	}
	public void setAmount(double amount) {
		this.amount = amount;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}


	
	
	
}
