package cn.nfleg.bean;

import java.util.Date;

public class ChatBean {
	private int sendUserID;
	private int recieveUserID;
	private String message;
	private Date time;

	
	
	public int getSendUserID() {
		return sendUserID;
	}
	public void setSendUserID(int sendUserID) {
		this.sendUserID = sendUserID;
	}
	public int getRecieveUserID() {
		return recieveUserID;
	}
	public void setRecieveUserID(int recieveUserID) {
		this.recieveUserID = recieveUserID;
	}
	public String getMessage() {
		return message;
	}
	public void setMessage(String message) {
		this.message = message;
	}
	public Date getTime() {
		return time;
	}
	public void setTime(Date time) {
		this.time = time;
	}

	
	

}
