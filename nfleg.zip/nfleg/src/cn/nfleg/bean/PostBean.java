package cn.nfleg.bean;

import java.util.Date;

public class PostBean {
	private short id;
	private int userID;
	private String userName;
	private String title;
	private String content;
	private String imgUrl;
	private Date time; //....
	private double amount;
	private String address;
	private short state;
	public short getId() {
		return id;
	}
	public void setId(short id) {
		this.id = id;
	}

	
	
	public int getUserID() {
		return userID;
	}
	public void setUserID(int userID) {
		this.userID = userID;
	}
	public String getUserName() {
		return userName;
	}
	public void setUserName(String userName) {
		this.userName = userName;
	}
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public String getContent() {
		return content;
	}
	public void setContent(String content) {
		this.content = content;
	}
	public String getImgUrl() {
		return imgUrl;
	}
	public void setImgUrl(String imgUrl) {
		this.imgUrl = imgUrl;
	}
	public Date getTime() {
		return time;
	}
	public void setTime(Date time) {
		this.time = time;
	}
	public double getAmount() {
		return amount;
	}
	public void setAmount(double amount) {
		this.amount = amount;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public short getState() {
		return state;
	}
	public void setState(short state) {
		this.state = state;
	}
	
	
	
	
}
