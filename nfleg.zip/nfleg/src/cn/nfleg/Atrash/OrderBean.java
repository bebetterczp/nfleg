//package cn.nfleg.Atrash;
//
//public class OrderBean {
//
//	private Integer id;
//	private int fromUserID;
//	private int toUserID;
//	private Integer postID;
//	private Double amount;
//	private Integer orderState;
//
//	public Integer getId() {
//		return id;
//	}
//
//	public void setId(Integer id) {
//		this.id = id;
//	}
//	
//
//	
//
//	public int getFromUserID() {
//		return fromUserID;
//	}
//
//	public void setFromUserID(int fromUserID) {
//		this.fromUserID = fromUserID;
//	}
//
//	public int getToUserID() {
//		return toUserID;
//	}
//
//	public void setToUserID(int toUserID) {
//		this.toUserID = toUserID;
//	}
//
//	public Integer getPostID() {
//		return postID;
//	}
//
//	public void setPostID(Integer postID) {
//		this.postID = postID;
//	}
//
//	public Double getAmount() {
//		return amount;
//	}
//
//	public void setAmount(Double amount) {
//		this.amount = amount;
//	}
//
//	public Integer getOrderState() {
//		return orderState;
//	}
//
//	public void setOrderState(Integer orderState) {
//		this.orderState = orderState;
//	}
//
//}
