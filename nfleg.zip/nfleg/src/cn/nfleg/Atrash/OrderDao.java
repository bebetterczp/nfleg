//package cn.nfleg.Atrash;
//
//public interface OrderDao {
//
//	boolean insertOrder(OrderBean orderBean);
//}
