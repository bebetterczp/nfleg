//package cn.nfleg.Atrash;
//
//	public interface OrderService {
//
//		/**
//		 * 接单。新增订单
//		 * @param userID 接单用户id
//		 * @param postID 帖子id
//		 * @return
//		 */
//		boolean addOrder(int userID,short postID);
//	}
//
