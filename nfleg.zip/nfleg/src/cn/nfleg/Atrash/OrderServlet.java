//package cn.nfleg.Atrash;
//
//import java.io.IOException;
//
//import javax.servlet.ServletException;
//import javax.servlet.annotation.WebServlet;
//import javax.servlet.http.HttpServlet;
//import javax.servlet.http.HttpServletRequest;
//import javax.servlet.http.HttpServletResponse;
//
//import cn.nfleg.bean.UserBean;
//
//@WebServlet("/order.action")
//public class OrderServlet extends HttpServlet {
//	private OrderService os = new OrderServiceImpl();
//	/**
//	 * 
//	 */
//	private static final long serialVersionUID = 1L;
//
//	/**
//     * @see HttpServlet#HttpServlet()
//     */
//    public OrderServlet() {
//        super();
//        // TODO Auto-generated constructor stub
//    }
//
//	/**
//	 * @see HttpServlet#service(HttpServletRequest request, HttpServletResponse response)
//	 */
//	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
//		String postID = request.getParameter("postID");
//		/*
//		 * 修改帖子状态 0-->1
//		 */
//		short pid = -1;
//		try {
//			pid = Short.parseShort(postID);
//		}catch (Exception e) {
//			response.sendRedirect("index.action");
//		}
//		
//		UserBean user = (UserBean)request.getSession().getAttribute("user");
//		os.addOrder(user.getId(), pid);
//		request.getRequestDispatcher("/WEB-INF/jsp/success.jsp").forward(request, response);
//	}
//
//}
