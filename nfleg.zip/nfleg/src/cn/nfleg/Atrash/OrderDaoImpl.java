//package cn.nfleg.Atrash;
//
//import java.sql.Connection;
//import java.sql.PreparedStatement;
//
//import cn.nfleg.dao.ConnectionFactory;
//
//public class OrderDaoImpl implements OrderDao {
//
//	public boolean insertOrder(OrderBean ob) {
//    try {
//    	//①获取连接
//		Connection  conn = ConnectionFactory.getConnection();
//		
//		//②创建sql语句  ?表示占位符
//		String  sql = "INSERT INTO order(fromUserID,toUserID,postID,amount,orderState) "
//				+ "VALUES(?,?,?,?,0)";
//		//③ 创建集装箱，装sql语句
//		PreparedStatement  preparedStatement = conn.prepareStatement(sql);
//		preparedStatement.setInt(1, ob.getFromUserID());
//		preparedStatement.setInt(2, ob.getToUserID());
//		preparedStatement.setInt(3, ob.getPostID());
//		preparedStatement.setDouble(4, ob.getAmount());
//		System.out.println("执行新增");
//		return preparedStatement.execute(sql);
//	} catch (Exception e) {
//		e.printStackTrace();
//	}
//    	return false;
//	}
//}
//
