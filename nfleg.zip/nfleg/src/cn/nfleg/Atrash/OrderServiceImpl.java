//package cn.nfleg.Atrash;
//
//import cn.nfleg.bean.PostBean;
//import cn.nfleg.service.PostService;
//import cn.nfleg.service.PostServiceImpl;
//
//public class OrderServiceImpl implements OrderService {
//
//	@Override
//	public boolean addOrder(int userID, short postID) {
//		
//		PostService ps = new PostServiceImpl();
//		OrderDao  orderDao = new OrderDaoImpl();
//		
//		/**
//		 * 1 判断该帖子的状态是否为0(已被接单)
//		 * 2 更新状态，并将订单新增至数据库
//		 */
//		PostBean post = ps.getPostByID(Integer.valueOf(postID));
//		System.out.println("post为空？："+post == null);
//		System.out.println("post的状态:"+post.getState());
//		if(post != null && post.getState() == 0) {
//			//修改状态，新增订单
//			if(ps.updatePostState(Integer.valueOf(postID))) {
//				//新增订单
//				OrderBean ob = new OrderBean();
//				ob.setFromUserID(post.getUserID());
//				ob.setAmount(post.getAmount());
//				ob.setOrderState(0);
//				ob.setToUserID(userID);
//				ob.setPostID(Integer.valueOf(postID));
//				
//				System.out.println("准备向数据库新增记录");
//				return orderDao.insertOrder(ob); 
//			}
//		}
//		return false;
//	}
//
//}
