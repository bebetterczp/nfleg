package cn.nfleg.dao;

import cn.nfleg.bean.UserBean;

public interface LoginDao {
	public UserBean getUser(Integer uid,String pwd);
}
