package cn.nfleg.dao;

import java.util.List;

import cn.nfleg.bean.PostBean;

public interface PostDao {
	public List<PostBean> getALLPost(); 
	public List<PostBean> getUserPost(int uid);
	public PostBean getPostByID(int postID);
	public boolean updatePostIntegerByID(int postID);
	public boolean addPost(PostBean postbean);
	public boolean delPost(int uid, int postID);
}
