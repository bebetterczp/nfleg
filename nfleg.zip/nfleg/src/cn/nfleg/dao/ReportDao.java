package cn.nfleg.dao;

import java.util.List;

import cn.nfleg.bean.ReportBean;

public interface ReportDao {
	public boolean AddReport(ReportBean reportbean);
	public List<ReportBean> queryAllReport();
}
