package cn.nfleg.dao;

import cn.nfleg.bean.Order_PostBean;
import java.util.List;

public interface OrderDao {
	public boolean addOrder(int uid,short pid);
	public List<Order_PostBean> getOrderByUid(int uid);
	public boolean FinishOrderByOid(int oid,int id);
	public boolean FinishOrderByPid(int pid,int id);
}
