package cn.nfleg.dao;

import java.util.List;
import cn.nfleg.bean.ChatBean;
import cn.nfleg.bean.UserBean;

public interface ChatDao {
	public boolean toUserExists(int uid);
	public List<ChatBean> chatList(int froUserID,int toUserID);
	public List<UserBean> chatUsers(int uid);
	public boolean AddChat(ChatBean chatbean);
}
