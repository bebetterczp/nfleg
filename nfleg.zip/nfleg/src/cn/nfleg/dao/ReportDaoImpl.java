package cn.nfleg.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import cn.nfleg.bean.ReportBean;

public class ReportDaoImpl implements ReportDao{

	@Override
	public boolean AddReport(ReportBean reportbean) {
		// TODO Auto-generated method stub
		try {
			Connection  conn = ConnectionFactory.getConnection();
			
			String  sql = "insert into report(fromUserID,reportType,toUserID,toPostID,reason,reportImgUrl) values(?,?,?,?,?,?)";

			

			PreparedStatement  preparedStatement = conn.prepareStatement(sql);
			
			
			preparedStatement.setInt(1, reportbean.getFromUserID());
			preparedStatement.setInt(2, reportbean.getReportType());
			preparedStatement.setInt(3, reportbean.getToUserID());
			preparedStatement.setShort(4, reportbean.getToPostID());
			preparedStatement.setString(5, reportbean.getReason());
			preparedStatement.setString(6, reportbean.getReportImgUrl());

			
			preparedStatement.executeUpdate();
			
			return true;
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return false;
		}
	}

	@Override
	public List<ReportBean> queryAllReport() {
		// TODO Auto-generated method stub
		
		try {
			Connection  conn = ConnectionFactory.getConnection();
			
			String  sql = "select * from report";

			PreparedStatement  preparedStatement = conn.prepareStatement(sql);
			

			
			ResultSet rs = preparedStatement.executeQuery();
			
			if(rs!=null) {
				List<ReportBean> reportlist = new ArrayList<ReportBean>();
				while(rs.next()) {
					int id = rs.getInt("id");
					int fromUserID = rs.getInt("fromUserID");
					short reportType = rs.getShort("reportType");
					int toUserID = rs.getInt("toUserID");
					short toPostID = rs.getShort("toPostID");
					String reason = rs.getString("reason");
					String reportImgUrl = rs.getString("reportImgUrl");
					
					ReportBean reportbean = new ReportBean();
					reportbean.setId(id);
					reportbean.setFromUserID(fromUserID);
					reportbean.setReportType(reportType);
					reportbean.setToUserID(toUserID);
					reportbean.setToPostID(toPostID);
					reportbean.setReason(reason);
					reportbean.setReportImgUrl(reportImgUrl);
					
					reportlist.add(reportbean);

				}
				return reportlist;
			}
			
			
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return null;
		}
		
		return null;
	}

}
