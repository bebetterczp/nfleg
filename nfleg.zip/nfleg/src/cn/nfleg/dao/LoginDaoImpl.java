package cn.nfleg.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import cn.nfleg.bean.UserBean;

public class LoginDaoImpl implements LoginDao{

	@Override
	public UserBean getUser(Integer uid,String pwd) {
		// TODO Auto-generated method stub
		
		if(uid==null || pwd == null){
			return null;
		}
		
		try {
			Connection  conn = ConnectionFactory.getConnection();
			String  sql = "SELECT * FROM user  WHERE  id = ? and password = ?";
			System.out.println("id:"+uid);
			System.out.println("pwd:"+pwd);
			PreparedStatement  preparedStatement = conn.prepareStatement(sql);
			preparedStatement.setInt(1, uid);
			preparedStatement.setString(2, pwd);
			ResultSet  rs = preparedStatement.executeQuery();
			if(rs != null && rs.next()) {	
				int id = rs.getInt("id");
				String userName = rs.getString("userName");
				String password  = rs.getString("password");
				double totalMoney = rs.getDouble("totalMoney");
				short publishAuth = rs.getShort("publishAuth");
				
				UserBean u = new UserBean();
				u.setId(id);
				u.setUserName(userName);
				u.setPassword(password);
				u.setTotalMoney(totalMoney);
				u.setPublishAuth(publishAuth);
				return u;
			}	
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
				
		return null;
		
	}
	
	
	
	

	
	
	
	
	

}
