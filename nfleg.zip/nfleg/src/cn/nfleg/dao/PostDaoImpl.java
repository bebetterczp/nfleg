package cn.nfleg.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import cn.nfleg.bean.PostBean;

public class PostDaoImpl implements PostDao{

	@Override
	public List<PostBean> getALLPost() {
		// TODO Auto-generated method stub
		ArrayList<PostBean> al = null; 
		try {
			Connection  conn = ConnectionFactory.getConnection();
			String  sql = "SELECT user.userName,post.* FROM post,user where user.id = post.userID";
			PreparedStatement  preparedStatement = conn.prepareStatement(sql);
			ResultSet  rs = preparedStatement.executeQuery();
			if(rs != null) {
				al = new ArrayList<PostBean>();
				while(rs.next()){
					short id = rs.getShort("id");
					int userID = rs.getInt("userID");
					String userName = rs.getString("userName");
					String title = rs.getString("title");
					String content = rs.getString("content");
					String imgUrl = rs.getString("imgUrl");
					Date time = rs.getDate("time");
					double amount = rs.getDouble("amount");
					String address = rs.getString("address");
					short state = rs.getShort("state");
					
					PostBean postBean = new PostBean();
					
					postBean.setId(id);
					postBean.setUserID(userID);
					postBean.setUserName(userName);
					postBean.setTitle(title);
					postBean.setContent(content);
					postBean.setImgUrl(imgUrl);
					postBean.setTime(time);
					postBean.setAmount(amount);
					postBean.setAddress(address);
					postBean.setState(state);
					al.add(postBean);
				}
				
				return al;
				
			}
			
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return null;
	}

	@Override
	public List<PostBean> getUserPost(int uid) {
		// TODO Auto-generated method stub
		ArrayList<PostBean> al = null; 
		
		try {
		
			Connection  conn = ConnectionFactory.getConnection();
			
		
			String  sql = "SELECT user.userName,post.* FROM post,user where user.id = post.userID and user.id = ?";
			
		
			PreparedStatement  preparedStatement = conn.prepareStatement(sql);
			preparedStatement.setInt(1, uid);
			
	
			ResultSet  rs = preparedStatement.executeQuery();
			
			if(rs != null) {
				al = new ArrayList<PostBean>();
				while(rs.next()){
					short id = rs.getShort("id");
					int userID = rs.getInt("userID");
					String userName = rs.getString("userName");
					String title = rs.getString("title");
					String content = rs.getString("content");
					String imgUrl = rs.getString("imgUrl");
					Date time = rs.getDate("time");
					double amount = rs.getDouble("amount");
					String address = rs.getString("address");
					short state = rs.getShort("state");
					
					PostBean postBean = new PostBean();
					
					postBean.setId(id);
					postBean.setUserID(userID);
					postBean.setUserName(userName);
					postBean.setTitle(title);
					postBean.setContent(content);
					postBean.setImgUrl(imgUrl);
					postBean.setTime(time);
					postBean.setAmount(amount);
					postBean.setAddress(address);
					postBean.setState(state);
					al.add(postBean);
				}
				
				return al;
				
			}
			
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return null;
	}

	@Override
	public PostBean getPostByID(int postID) {

		Connection  conn = ConnectionFactory.getConnection();

		String  sql = "SELECT id,userID,title,content,imgUrl,time,amount,address,state  FROM post,user where id = ?";

		PreparedStatement preparedStatement;
		PostBean postBean = null;
		try {
			preparedStatement = conn.prepareStatement(sql);
			preparedStatement.setInt(1, postID);

			ResultSet  rs = preparedStatement.executeQuery();
			if(rs != null) {
				short id = rs.getShort("id");
				int userID = rs.getInt("userID");
				String userName = rs.getString("userName");
				String title = rs.getString("title");
				String content = rs.getString("content");
				String imgUrl = rs.getString("imgUrl");
				Date time = rs.getDate("time");
				double amount = rs.getDouble("amount");
				String address = rs.getString("address");
				short state = rs.getShort("state");
				
			   postBean = new PostBean();
				
				postBean.setId(id);
				postBean.setUserID(userID);
				postBean.setUserName(userName);
				postBean.setTitle(title);
				postBean.setContent(content);
				postBean.setImgUrl(imgUrl);
				postBean.setTime(time);
				postBean.setAmount(amount);
				postBean.setAddress(address);
				postBean.setState(state);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
		return postBean;
	}

	@Override
	public boolean updatePostIntegerByID(int postID) {

				Connection  conn = ConnectionFactory.getConnection();

				String  sql = "update post set state = 1 where id = ?";

				PreparedStatement preparedStatement;
				int result = 0;
				try {
					preparedStatement = conn.prepareStatement(sql);
					preparedStatement.setInt(1, postID);
				    result  = preparedStatement.executeUpdate();
				} catch (SQLException e) {
					e.printStackTrace();
				}
				
				return result > 0;
	}

	@Override
	public boolean addPost(PostBean postbean) {
		// TODO Auto-generated method stub
		try {
			int uid = postbean.getUserID();
			double amount = postbean.getAmount();
			Connection  conn = ConnectionFactory.getConnection();
			
			
			
			
			String sql = "select totalMoney from user where id = ?";
			PreparedStatement  preparedStatement = conn.prepareStatement(sql);
			preparedStatement.setInt(1, uid);
			ResultSet rs = preparedStatement.executeQuery();
			if(rs!=null) {
				if(rs.next()) {
					if(amount>rs.getDouble("totalMoney")) {
						return false;
					}else {
						sql = "update user set totalMoney=totalMoney - ? where id = ?";
						System.out.println(sql);
						preparedStatement = conn.prepareStatement(sql);
						preparedStatement.setDouble(1, amount);
						preparedStatement.setInt(2, uid);
						preparedStatement.executeUpdate();
						
					}
				}else {
					return false;
				}
			}else {
				return false;
			}
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			sql = "insert into post(userID,title,content,imgUrl,time,amount,address,state) values(?,?,?,?,now(),?,?,?)";
			
			preparedStatement = conn.prepareStatement(sql);
			
			preparedStatement.setInt(1, postbean.getUserID());
			preparedStatement.setString(2, postbean.getTitle());
			preparedStatement.setString(3, postbean.getContent());
			preparedStatement.setString(4, postbean.getImgUrl());
//			preparedStatement.setTimestamp(6, new java.sql.Timestamp(postbean.getTime().getTime()));
			preparedStatement.setDouble(5, postbean.getAmount());
			preparedStatement.setString(6, postbean.getAddress());
			preparedStatement.setShort(7, (short)0);
			
			preparedStatement.executeUpdate();
			
			
			return true;

			
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();

		}
		return false;
	}

	@Override
	public boolean delPost(int uid, int postID) {
		// TODO Auto-generated method stub
		
		try {
			Connection  conn = ConnectionFactory.getConnection();
			String  check_sql = "SELECT * from post where id = ? and state = 0";
			PreparedStatement preparedStatement = conn.prepareStatement(check_sql);
			preparedStatement.setInt(1, postID);
			ResultSet  rs = preparedStatement.executeQuery();
			if(rs!=null) {
				if(rs.next()) {
					if(rs.getInt("userID")==uid) {
						double amnout = rs.getDouble("amount");
						String refundsql = "update user set totalMoney=totalMoney + ? where id = ?";
						preparedStatement = conn.prepareStatement(refundsql);
						preparedStatement.setDouble(1, amnout);
						preparedStatement.setInt(2, uid);
						preparedStatement.executeUpdate();
						
						String delsql = "delete from post where id = ?";
						preparedStatement = conn.prepareStatement(delsql);
						preparedStatement.setInt(1, postID);
						preparedStatement.executeUpdate();
						return true;
					}else {
						return false;
					}
					
				}else {
					return false;
				}
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
		return false;
	}

}
