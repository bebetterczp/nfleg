package cn.nfleg.dao;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import cn.nfleg.bean.ChatBean;
import cn.nfleg.bean.UserBean;

public class ChatDaoImpl implements ChatDao{

	@Override
	public boolean toUserExists(int uid) {
		// TODO Auto-generated method stub
		try {

			Connection  conn = ConnectionFactory.getConnection();
			

			String  sql = "SELECT * FROM user  WHERE  id = ?";
			
			System.out.println("id:"+uid);
			

			PreparedStatement  preparedStatement = conn.prepareStatement(sql);

			preparedStatement.setInt(1, uid);
			
			

			ResultSet  rs = preparedStatement.executeQuery();
			
			if(rs != null && rs.next()) {
				
				return true;
				
			}
			return false;
			
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return false;
	}

	@Override
	public List<ChatBean> chatList(int froUserID, int toUserID) {
		// TODO Auto-generated method stub
		
		try {
			Connection  conn = ConnectionFactory.getConnection();
			
			String  sql = "select * from chats where (SendUserID = ? and RecieveUserID = ?) or (SendUserID = ? and RecieveUserID = ?) order by time";

			

			PreparedStatement  preparedStatement = conn.prepareStatement(sql);

			preparedStatement.setInt(1, froUserID);
			preparedStatement.setInt(2, toUserID);
			preparedStatement.setInt(3, toUserID);
			preparedStatement.setInt(4, froUserID);
			
			

			ResultSet  rs = preparedStatement.executeQuery();
			
			if(rs != null) {
				ArrayList<ChatBean> al = new ArrayList<ChatBean>();
				while(rs.next()){
					int SendUserID = rs.getInt("SendUserID");
					int RecieveUserID = rs.getInt("RecieveUserID");
					String message = rs.getString("message");
					Date time = rs.getDate("time");
					
					ChatBean chatbean = new ChatBean();
					chatbean.setSendUserID(SendUserID);
					chatbean.setRecieveUserID(RecieveUserID);
					chatbean.setMessage(message);
					chatbean.setTime(time);
					al.add(chatbean);
				}
				
				return al;
			}
			
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return null;
	}

	@Override
	public List<UserBean> chatUsers(int uid) {
		// TODO Auto-generated method stub
		try {

			Connection  conn = ConnectionFactory.getConnection();
			
		
			
			String  sql1 = "select DISTINCT(SendUserID),userName from chats,user where (RecieveUserID = ? and SendUserID=`user`.id) order by time";
			String  sql2 = "select DISTINCT(RecieveUserID),userName from chats,user where (SendUserID = ? and RecieveUserID=`user`.id) order by time";
			
		
			PreparedStatement  preparedStatement = conn.prepareStatement(sql1);

			preparedStatement.setInt(1, uid);

			
			

			ResultSet  rs = preparedStatement.executeQuery();
			ArrayList<UserBean> al1 = new ArrayList<UserBean>();
			ArrayList<UserBean> al2 = new ArrayList<UserBean>();
			if(rs != null) {
				
				while(rs.next()){
					int id = rs.getInt("SendUserID");
					String userName = rs.getString("userName");
					
					UserBean userbean = new UserBean();
					userbean.setId(id);
					userbean.setUserName(userName);
					
					al1.add(userbean);
				}
			}
			/////////////////////
			
			preparedStatement = conn.prepareStatement(sql2);

			preparedStatement.setInt(1, uid);

			

			rs = preparedStatement.executeQuery();
			
			if(rs != null) {
				while(rs.next()){
					int id = rs.getInt("RecieveUserID");
					String userName = rs.getString("userName");
					
					UserBean userbean = new UserBean();
					userbean.setId(id);
					userbean.setUserName(userName);
					
					al2.add(userbean);
				}
			}
			
			
			
			return CombineList(al1, al2);
			
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return null;
	}
	
	private  ArrayList<UserBean> CombineList(ArrayList<UserBean> al1, ArrayList<UserBean> al2){
		ArrayList<UserBean> NewList = new ArrayList<>();
		for(int i=0;i<al1.size();i++){
			if(NewList.size()==0){
				NewList.add(al1.get(i));
			}else{
				boolean exits = false;
				for(int j=0;j<NewList.size();j++){
					if(NewList.get(j).getUserName().contentEquals((al1.get(i)).getUserName())){
						exits = true;
						break;
					}
				}
				if(!exits){
					NewList.add(al1.get(i));
				}
			}
			
		}
		
		
		for(int i=0;i<al2.size();i++){
			if(NewList.size()==0){
				NewList.add(al2.get(i));
			}else{
				boolean exits = false;
				for(int j=0;j<NewList.size();j++){
					if(NewList.get(j).getUserName().contentEquals((al2.get(i)).getUserName())){
						exits = true;
						break;
					}
				}
				if(!exits){
					NewList.add(al2.get(i));
				}
			}
			
		}
		
		return NewList;
	}

	@Override
	public boolean AddChat(ChatBean chatbean) {
		// TODO Auto-generated method stub
		
		try {
			Connection  conn = ConnectionFactory.getConnection();
			
			String  sql = "insert into chats values(?,?,?,?)";

			

			PreparedStatement  preparedStatement = conn.prepareStatement(sql);
			
			
			preparedStatement.setInt(1, chatbean.getSendUserID());
			preparedStatement.setInt(2, chatbean.getRecieveUserID());
			preparedStatement.setString(3, chatbean.getMessage());
			preparedStatement.setTimestamp(4, new java.sql.Timestamp(chatbean.getTime().getTime()));
			
			preparedStatement.executeUpdate();
			
			return true;
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return false;
		}
		

	}

}
