package cn.nfleg.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;


public class UserDaoImpl implements UserDao{

	@Override
	public boolean updateInfo(int uid , String uname, String upwd) {
		// TODO Auto-generated method stub
		try {
			if(uname == null || upwd == null) {
				return false;
			}
			
			Connection conn = ConnectionFactory.getConnection();
			String sql = "update user set userName = ? , password = ? where id = ?";
			PreparedStatement preparedstatement = conn.prepareStatement(sql);
			preparedstatement.setString(1, uname);
			preparedstatement.setString(2, upwd);
			preparedstatement.setInt(3, uid);
			
			preparedstatement.executeUpdate();
			return true;
			
		}catch(Exception e) {
			
		}
		
		return false;
	}

	@Override
	public boolean addMoney(int uid, double amount) {
		// TODO Auto-generated method stub
		
		try {
			Connection conn = ConnectionFactory.getConnection();
			String sql = "update user set totalMoney=totalMoney+ ? where id = ?";
			PreparedStatement preparedstatement = conn.prepareStatement(sql);
			preparedstatement.setDouble(1, amount);
			preparedstatement.setInt(2, uid);
			
			preparedstatement.executeUpdate();
			return true;
			
		}catch (Exception e) {
			
		}
		return false;
	}

	@Override
	public double showMoney(int uid) {
		// TODO Auto-generated method stub
		try {
			Connection conn = ConnectionFactory.getConnection();
			String sql = "select totalMoney from user where id = ?";
			PreparedStatement preparedstatement = conn.prepareStatement(sql);
			preparedstatement.setInt(1, uid);
			
			ResultSet rs = preparedstatement.executeQuery();
			if(rs!=null) {
				if(rs.next()) {
					return rs.getDouble("totalMoney");
				}else {
					return -1;
				}
			}
			
		}catch (Exception e) {
			
		}
		return -1;
	}

	@Override
	public int register(String uname, String upwd) {
		// TODO Auto-generated method stub
		
		try {
			Connection conn = ConnectionFactory.getConnection();
			String sql = "insert into user(userName,password,totalMoney,publishAuth) values(?,?,0,1)";
			PreparedStatement ps = conn.prepareStatement(sql);
			ps.setString(1, uname);
			ps.setString(2, upwd);
			if(ps.executeUpdate()>0) {
				sql = "select id from user where userName = ? and password = ?";
				ps = conn.prepareStatement(sql);
				ps.setString(1, uname);
				ps.setString(2, upwd);
				ResultSet rs = ps.executeQuery();
				if(rs!=null) {
					if(rs.next()) {
						return rs.getInt("id");
					}
				}
			}else {
				return -1;
			}
		}catch(Exception e) {
			e.printStackTrace();
			
		}
		return -1;
	}

}
