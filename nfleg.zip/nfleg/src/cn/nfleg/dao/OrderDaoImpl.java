package cn.nfleg.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import cn.nfleg.bean.Order_PostBean;

public class OrderDaoImpl implements OrderDao{

	@Override
	public boolean addOrder(int uid, short pid) {
		// TODO Auto-generated method stub
		try {
			Connection  conn = ConnectionFactory.getConnection();
			String  sql = "SELECT * FROM post WHERE id = ? and state=0";
			PreparedStatement  preparedStatement = conn.prepareStatement(sql);
			preparedStatement.setInt(1, pid);
			ResultSet  rs = preparedStatement.executeQuery();
			
			if(rs.next()) {
				int userID = rs.getInt("userID");
				if(userID==uid) {
					return false;
				}
				sql = "update post set state=1 where id = ?";
				preparedStatement = conn.prepareStatement(sql);
				preparedStatement.setInt(1, pid);
				preparedStatement.executeUpdate();
				
				sql = "insert into `order`(fromUserID,postID,orderState1,orderState2,appraiseID) values(?,?,?,?,?)";
				preparedStatement = conn.prepareStatement(sql);
				preparedStatement.setInt(1, uid);
				preparedStatement.setShort(2, pid);
				preparedStatement.setShort(3, (short)0);
				preparedStatement.setShort(4, (short)0);
				preparedStatement.setShort(5, (short)0);
				System.out.println(preparedStatement.toString());
				preparedStatement.executeUpdate();
				
			}else {
				return false;
			}
				
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return false;
	}

	@Override
	public List<Order_PostBean> getOrderByUid(int uid) {
		// TODO Auto-generated method stub
		try {
			Connection  conn = ConnectionFactory.getConnection();
			String  sql = "SELECT `user`.userName,`order`.id as oid,`order`.orderState1,`order`.orderState2,`order`.appraiseID, post.* FROM `user`,`order`,post WHERE fromUserID = ? and `order`.postID = post.id and `user`.id = post.userID;";
			PreparedStatement  preparedStatement = conn.prepareStatement(sql);
			preparedStatement.setInt(1, uid);
			ResultSet  rs = preparedStatement.executeQuery();
			
			List<Order_PostBean> list = null;
			
			if(rs!=null) {
				list = new ArrayList<Order_PostBean>();
				while(rs.next()) {
					Order_PostBean opbean = new Order_PostBean();
					
					int oid = rs.getInt("oid");
					short orderState1 = rs.getShort("orderState1");
					short orderState2 = rs.getShort("orderState2");
					short appraiseID = rs.getShort("appraiseID");
					short pid = rs.getShort("id");
					int userID = rs.getInt("userID");
					String title = rs.getString("title");
					String content = rs.getString("content");
					String imgUrl = rs.getString("imgUrl");
					Date time = rs.getDate("time");
					double amount = rs.getDouble("amount");
					String address = rs.getString("address");
					String userName = rs.getString("userName");
					
					opbean.setOid(oid);
					opbean.setOrderState1(orderState1);
					opbean.setOrderState2(orderState2);
					opbean.setAppraiseID(appraiseID);
					opbean.setPid(pid);
					opbean.setUserID(userID);
					opbean.setTitle(title);
					opbean.setContent(content);
					opbean.setImgUrl(imgUrl);
					opbean.setTime(time);
					opbean.setAmount(amount);
					opbean.setAddress(address);
					opbean.setUserName(userName);
					
					list.add(opbean);
				}
				return list;
			}
			
				
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return null;
	}

	@Override
	public boolean FinishOrderByOid(int oid, int id) {
		// TODO Auto-generated method stub
		try {
			Connection conn = ConnectionFactory.getConnection();
			String sql = "select fromUserID from `order` where id = ? and orderState2 = 0";
			PreparedStatement ps = conn.prepareStatement(sql);
			ps.setInt(1, oid);
			
			int uid = -1;
			
			ResultSet rs = ps.executeQuery();
			if(rs!=null) {
				if(rs.next()) {
					uid = rs.getInt("fromUserID");
				}
				
			}
			
			if(uid != id) {
				System.out.println("idNotEqual");
				return false;
			}
			
			sql = "select orderState1 from `order` where id =?";
			ps = conn.prepareStatement(sql);
			ps.setInt(1, oid);
			rs = ps.executeQuery();
			if(rs!=null) {
				if(rs.next()) {
					if(rs.getInt("orderState1")==1) {
						sql = "update post set state = 3 where id = (select postID from `order` where id = ? ) and state =2";
						ps = conn.prepareStatement(sql);
						ps.setInt(1, oid);
						ps.executeUpdate();
						
						sql = "update `user` set totalMoney=totalMoney+(select amount from post where id = (select postID from `order` where id = ?) ) where id = (select fromUserID from `order` where id = ?)";
						ps = conn.prepareStatement(sql);
						ps.setInt(1, oid);
						ps.setInt(2, oid);
						ps.executeUpdate();
					}
				}
			}
			
			
			
			
			
			sql = "update `order` set orderState2 = 1 where id = ?";
			ps = conn.prepareStatement(sql);
			ps.setInt(1, oid);
			if(ps.executeUpdate()>0) {
				return true;
			}else {
				return false;
			}
			
			
		}catch(Exception e) {
			e.printStackTrace();
		}
		
		
		
		return false;
	}

	@Override
	public boolean FinishOrderByPid(int pid, int id) {
		// TODO Auto-generated method stub
		try {
			Connection conn = ConnectionFactory.getConnection();
			String sql = "select userID from `post` where id = ? and state = 1";
			PreparedStatement ps = conn.prepareStatement(sql);
			ps.setInt(1, pid);
			
			int uid = -1;
			ResultSet rs = ps.executeQuery();
			if(rs!=null) {
				if(rs.next()) {
					uid = rs.getInt("userID");
				}
				
			}
//			System.out.println(uid+"fdsf"+id);
			if(uid!=id) {
				return false;
			}
//			System.out.println("fsdfd");
			
			sql = "select orderState2 as snum from `order` where postID = ?";
			ps = conn.prepareStatement(sql);
			ps.setInt(1, pid);
			rs = ps.executeQuery();
			if(rs!=null) {
				if(rs.next()) {
					short temp = rs.getShort("snum");
					if(temp==(short)1) {
						sql = "update `user` set totalMoney = totalMoney + (select amount from post where id = ?) where id = (select fromUserID from `order` where postID = ?)";
						ps = conn.prepareStatement(sql);
						ps.setInt(1, pid);
						ps.setInt(2, pid);
						ps.executeUpdate();
						
						sql = "update post set state = 3 where id = ? and state =1";
						
					}else if(temp==(short)0){
						sql = "update post set state = 2 where id = ? and state =1";
					}else {
						return false;
					}
					ps = conn.prepareStatement(sql);
					ps.setInt(1, pid);
					ps.executeUpdate();
				}
			}
			
			
			
		
			
			sql = "update `order` set orderState1 = 1 where postID = ?";
			ps = conn.prepareStatement(sql);
			ps.setInt(1, pid);
			System.out.println(ps.toString());
			if(ps.executeUpdate()>0) {
				return true;
			}else {
				return false;
			}
			
			
		}catch(Exception e) {
			e.printStackTrace();
		}
		
		
		
		return false;
	}

}
