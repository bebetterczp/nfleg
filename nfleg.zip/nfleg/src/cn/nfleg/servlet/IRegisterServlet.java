package cn.nfleg.servlet;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import cn.nfleg.bean.UserBean;
import cn.nfleg.service.LoginService;
import cn.nfleg.service.LoginServiceImpl;
import cn.nfleg.service.UserService;
import cn.nfleg.service.UserServiceImpl;

/**
 * Servlet implementation class Iregister
 */
@WebServlet("/Iregister")
public class IRegisterServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public IRegisterServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#service(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		request.setCharacterEncoding("UTF-8");
		response.setCharacterEncoding("UTF-8");
		String uname = request.getParameter("uname");
		String upwd = request.getParameter("upwd");
		if(uname==null || uname.length()==0 || upwd==null || upwd.length()==0) {
			response.sendRedirect("register");
			return;
		}
		UserService userservice  = new UserServiceImpl();
		LoginService ls = new LoginServiceImpl();
		int id = -1;
		if( (id = userservice.register(uname, upwd)) !=-1) {
			UserBean user = ls.getUser(id, upwd);
			if(user==null) {
				request.setAttribute("mess", "注册成功，你的账号是"+id);
			}else {
				request.getSession().setAttribute("user", user);
				request.setAttribute("mess", "注册成功，你的账号是"+id+"<a href=\"index.action\">进入首页</a>");
			}
			
		}else {
			request.setAttribute("mess", "注册失败，请<a href=\"register\">重试</a>");
		}
		request.getRequestDispatcher("/WEB-INF/registerResult.jsp").forward(request, response);
		
	}

}
