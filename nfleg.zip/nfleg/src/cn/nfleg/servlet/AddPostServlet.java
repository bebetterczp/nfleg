package cn.nfleg.servlet;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import cn.nfleg.bean.PostBean;
import cn.nfleg.bean.UserBean;
import cn.nfleg.service.PostService;
import cn.nfleg.service.PostServiceImpl;

/**
 * Servlet implementation class AddPostServlet
 */
@WebServlet("/addPost")
public class AddPostServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	
	private PostService ps = new PostServiceImpl();
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public AddPostServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#service(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		request.setCharacterEncoding("UTF-8");
		response.setCharacterEncoding("UTF-8");

		/*
		 *  "content":content,
            "userID":userID,
		    "amount":amount
		 */
		
		PrintWriter out = response.getWriter();
		
		HttpSession session = request.getSession();
		UserBean user = (UserBean) session.getAttribute("user");
		
		String content = request.getParameter("content");
		int userID = user.getId();
		String Samount = request.getParameter("amount");
		
		System.out.println(content);
		System.out.println(userID);
		
		double amount = 0.0;
		try {
			amount = Double.parseDouble(Samount);
		}catch (Exception e) {}
		System.out.println(amount);
		PostBean post = new PostBean();
		post.setAmount(amount);
		post.setContent(content);
		post.setUserID(userID);
		
		if(ps.addPost(post)) {
			out.write("SUCCESS");
		}else {
			out.write("ERROR");
		}
		
		
	}

}
