package cn.nfleg.servlet;

import java.io.IOException;
import java.util.Calendar;
import java.util.Date;
import java.util.TimeZone;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import cn.nfleg.bean.ChatBean;
import cn.nfleg.bean.UserBean;
import cn.nfleg.service.ChatService;
import cn.nfleg.service.ChatServiceImpl;

/**
 * Servlet implementation class AddChatServlet
 */
@WebServlet("/addChat")
public class AddChatServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public AddChatServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#service(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		request.setCharacterEncoding("UTF-8");
		response.setCharacterEncoding("UTF-8");
		
		String Touid = request.getParameter("uid");
		int touid = -1;
		try {
			touid = Integer.parseInt(Touid);
		}catch(Exception e) {
			
		}
		
		UserBean user = (UserBean) request.getSession().getAttribute("user");
		int frouid = user.getId();
		
		
		String content = request.getParameter("content");
		System.out.println(Touid+"---"+content);
		Calendar cal = Calendar.getInstance(TimeZone.getTimeZone("GMT+8"));
		
		Date date = new Date(cal.getTimeInMillis());
		
		ChatBean chatbean = new ChatBean();
		
		chatbean.setSendUserID(frouid);
		chatbean.setRecieveUserID(touid);
		chatbean.setMessage(content);
		chatbean.setTime(date);
		
		ChatService cs = new ChatServiceImpl();
		cs.AddChat(chatbean);
		
		response.sendRedirect("Chats?step=2&uid="+Touid);
		
		
	}

}
