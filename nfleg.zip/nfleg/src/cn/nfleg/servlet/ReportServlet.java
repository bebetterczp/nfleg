package cn.nfleg.servlet;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 * Servlet implementation class ReportServlet
 */
@WebServlet("/Report")
public class ReportServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public ReportServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#service(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		request.setCharacterEncoding("UTF-8");
		response.setCharacterEncoding("UTF-8");
		
		String uid = request.getParameter("uid");
		String pid = request.getParameter("pid");
		HttpSession session = request.getSession(true);
		
		if((uid==null && pid ==null) || (uid!=null && pid !=null) ) {
			response.sendRedirect("index.action");
			return;
		}
		

		if(uid!=null) {
			session.setAttribute("type", "0");
			session.setAttribute("uid", uid);
		}else{
			session.setAttribute("type", "1");
			session.setAttribute("pid", pid);
		}
			
		request.getRequestDispatcher("/WEB-INF/jsp/report.jsp").forward(request, response);
		
	}

}
