package cn.nfleg.servlet;

import java.io.IOException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import cn.nfleg.bean.PostBean;
import cn.nfleg.bean.UserBean;
import cn.nfleg.service.PostService;
import cn.nfleg.service.PostServiceImpl;

/**
 * Servlet implementation class PostServlet
 */
@WebServlet("/index.action")
public class PostServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public PostServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#service(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		request.setCharacterEncoding("UTF-8");
		response.setCharacterEncoding("UTF-8");
		
		HttpSession session = request.getSession(true);
		UserBean user = null;
		try {
			user = (UserBean) session.getAttribute("user");
			if (user == null) {
				user  = new UserBean();
				session.setAttribute("user", user);
			}
		} catch (Exception exp) {
			user  = new UserBean();
			session.setAttribute("user", user);
		}
		
		PostService ps = new PostServiceImpl();
		user = (UserBean) request.getSession().getAttribute("user");
		String rqu_showMethod = request.getParameter("showMethod");
		String sess_showMethod = null;
		String showMethod = "all";
		try{
			sess_showMethod =  (String) request.getSession().getAttribute("showMethod");
		}catch(Exception e){
			sess_showMethod = "all";
			request.getSession().setAttribute("showMethod", "all");
			}
		
		if( rqu_showMethod!=null && (rqu_showMethod.contentEquals("all") || rqu_showMethod.contentEquals("user")) ){
			showMethod = rqu_showMethod;
			request.getSession().setAttribute("showMethod", rqu_showMethod);
		}else if(sess_showMethod==null ){
			request.getSession().setAttribute("showMethod", "all");
		}
		
		if(user.getId()==-1 || showMethod.contentEquals("all")){
			
			List<PostBean> postList =  ps.getALLPost();
			
//			for( PostBean pb : postList ){
//				System.out.println(pb.getContent());
//			}
			System.out.println("quanbu");
			
			request.getSession().setAttribute("postList", postList);
		}else{
			int uid = user.getId();
			
			List<PostBean> postList = ps.getUserPost(uid);
//			for( PostBean pb : postList ){
//				System.out.println(pb.getContent());
//			}
			
			System.out.println("user-Only");
			
			request.getSession().setAttribute("postList", postList);
			
		}
		
		request.getRequestDispatcher("/WEB-INF/index.jsp").forward(request, response);
		
		
	}

}
