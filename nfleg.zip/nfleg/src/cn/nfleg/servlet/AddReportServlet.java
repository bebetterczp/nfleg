package cn.nfleg.servlet;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import cn.nfleg.bean.ReportBean;
import cn.nfleg.bean.UserBean;
import cn.nfleg.service.ReportService;
import cn.nfleg.service.ReportServiceImpl;

/**
 * Servlet implementation class AddReportServlet
 */
@WebServlet("/addReport")
public class AddReportServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public AddReportServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#service(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		request.setCharacterEncoding("UTF-8");
		response.setCharacterEncoding("UTF-8");
		
		String reason = request.getParameter("reason");
		String toUid = request.getParameter("uid");
		String toPid = request.getParameter("pid");
		System.out.println(toPid);
		String strType = request.getParameter("type");
		int tuid = -1;
		short tpid = -1;
		
		if(strType==null) {
			strType = "0";
		}
		short type = 0;
		try {
			type = (short) Integer.parseInt(strType);
		}catch(Exception e) {}
		
		UserBean user = (UserBean) request.getSession().getAttribute("user");
		int uid = user.getId();
		
		ReportBean reportbean = new ReportBean();
		reportbean.setFromUserID(uid);//
		if(toUid!=null) {
			try {
				tuid = Integer.parseInt(toUid);
			}catch (Exception e) {
				response.sendRedirect("index.action");
				return;
			}
			reportbean.setToUserID(tuid);//
		}else {
			try {
				tpid = Short.parseShort(toPid);
			}catch (Exception e) {
				response.sendRedirect("index.action");
				return;
			}
			reportbean.setToPostID(tpid);
		}
		reportbean.setReportType(type);//
		reportbean.setReason(reason);
		
		ReportService reportservice = new ReportServiceImpl();
		reportservice.AddReport(reportbean);
		
		request.getRequestDispatcher("index.action").forward(request, response);
		
	}

}
