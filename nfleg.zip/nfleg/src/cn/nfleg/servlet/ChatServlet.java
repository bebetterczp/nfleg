package cn.nfleg.servlet;

import java.io.IOException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import cn.nfleg.bean.ChatBean;
import cn.nfleg.bean.UserBean;
import cn.nfleg.service.ChatService;
import cn.nfleg.service.ChatServiceImpl;

/**
 * Servlet implementation class ChatServlet
 */
@WebServlet("/Chats")
public class ChatServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public ChatServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#service(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		request.setCharacterEncoding("UTF-8");
		response.setCharacterEncoding("UTF-8");
		ChatService cs = new ChatServiceImpl();
		String step = request.getParameter("step");
		if(step==null){
			step = "1";
		}
		
		String chatUid = request.getParameter("uid");
		int cid = -1;
		int uid = ((UserBean)request.getSession().getAttribute("user")).getId();
		if(chatUid==null){
			step="1";
		}else{
			try {
				cid = Integer.parseInt(chatUid);
			}catch(Exception e) {
				response.sendRedirect("index.action");
				return;
			}
			
			
			if(chatUid.contentEquals(uid+"")) {
				response.sendRedirect("index.action");
				return;
			}
			if(!cs.toUserExists(cid)){
				step="1";
			}
			
		}
		
		
		
		
		if(step.contentEquals("1")){
			System.out.println("111111");
			List<UserBean> userList = null;
			userList = cs.chatUsers(uid);
			
			for(UserBean ub : userList){
				System.out.println(ub.getUserName());
			}
			
			request.getSession().setAttribute("userList", userList);
			request.getSession().setAttribute("step", step);
		}else if(step.contentEquals("2")){
			System.out.println("22222");
			List<ChatBean> chatlist = cs.chatList(uid, cid);
			request.getSession().setAttribute("step", step);
			request.getSession().setAttribute("uid", chatUid);
			request.getSession().setAttribute("chatlist", chatlist);
		}
		
		request.getRequestDispatcher("/WEB-INF/jsp/chats.jsp").forward(request, response);
	}

}
