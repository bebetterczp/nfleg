package cn.nfleg.servlet;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import cn.nfleg.bean.UserBean;
import cn.nfleg.service.LoginService;
import cn.nfleg.service.LoginServiceImpl;

/**
 * Servlet implementation class LoginServlet
 */
@WebServlet("/login.action")
public class LoginServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public LoginServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#service(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		request.setCharacterEncoding("UTF-8");
		response.setCharacterEncoding("UTF-8");
		PrintWriter out = response.getWriter();
		String Suid = request.getParameter("id");
		int uid = -1;
		try {
			uid = Integer.parseInt(Suid);
		}catch(Exception e) {
			out.write("ERROR");
			return;
		}
		
		String pwd = request.getParameter("password");
		
		System.out.println("Servlet:"+uid+"---"+pwd);
		
		HttpSession session = request.getSession(true);
		
		LoginService los = new LoginServiceImpl();
		
		UserBean user = null;
		
		try {
			user = (UserBean) session.getAttribute("user");
			if (user == null) {
				user  = new UserBean();
				session.setAttribute("user", user);
			}
		} catch (Exception exp) {
			user  = new UserBean();
			session.setAttribute("user", user);
		}
		
		
		if((user=los.getUser(uid, pwd))!=null){
//			session.setAttribute("user", user);
			request.getSession().setAttribute("user", user);
			System.out.println(user.getId()+"登录");
			out.write("SUCCESS");
		}else{
			out.write("ERROR");
		}
	}

}
