function header(name){
	if (name == null || name == "" || name.length == 0){
		str += "	<li>";
		str += "		<span>";
		str += "			[<a href=\"login.jsp\">登录</a>]";
		str += "			[<a href=\"register.action\">免费注册</a>]";
		str += "		</span>";
		str += "	</li>";
	}else{
		str += "	<li>";
		str += "		<span style='color:red;'>" + name;
		str += "		</span>：您好!&nbsp;&nbsp;";
		str += "		[<a href=\"loginout.action\">退出</a>]";
		str += "	</li>";
	}
	document.write(str);
};