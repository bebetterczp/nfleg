$(document).ready(function(){
	$("#login_button").click(function(){
		var userNum = $("#userNum").val();
		var password = $("#password").val();
		if(userNum==null  || password == null || userNum==""  || password == ""){
			alert("请输入完整");
			return;
		}
		
		$.ajax({
			url:"login.action",
			type:"GET",
			data:{
				"id":userNum,
				"password":password
			},
			success:function(data){
				//alert(data);
				if(data=="SUCCESS"){
					window.location.href="index.action";
//					window.location.href="user/student/"+userNum;
				
//				$(location).attr('href', 'user/student/'+userNum);
				}
				if(data == "ERROR"){
					//alert(data+"登录失败");
				}
			},
			error:function(data){
				//alert("error:"+data.readyState);
			}
			});
		});
});