$(document).ready(function(){
	
	$.ajax({
		url:"post/list",
		type:"GET"
	});
	
	$("#add_post").click(function(){
		//alert("1111");
		var content = $("#content").val();
		var userID = $("#userID").val();
		var amount = $("#amount").val();
//		var data = {
//				"content":content,
//				"userID":userID,
//				"amount":amount
//		};
		//向后台提交新增请求
		//alert(content);
		$.ajax({
			url:"addPost",
			type:"POST",
//			contentType:"application/json",
			data:{
				"content":content,
				"userID":userID,
				"amount":amount
				
			},
			success:function(data){
				if(data == "SUCCESS"){
					window.location.reload();
					//alert("新增成功");
				}
				if(data == "ERROR"){
					alert("新增失败");
				}
			},
		error:function(data){
			alert("请求出错");
		}
				
		});
	});
	
});


function receipt(postID){
	//alert(postID);
	$.ajax({
		url:"order.action",
		type:"GET",
		data:{
			"postID":postID
		}
	});
}











